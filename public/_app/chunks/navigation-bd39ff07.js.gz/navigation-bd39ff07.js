import{r}from"./singletons-a6a7384f.js";const s=n;async function n(o,t){return r.goto(o,t,[])}export{s as g};
